﻿namespace Week2Proj01
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxInput1 = new System.Windows.Forms.TextBox();
            this.tbxInput2 = new System.Windows.Forms.TextBox();
            this.tbxInput3 = new System.Windows.Forms.TextBox();
            this.tbxInput4 = new System.Windows.Forms.TextBox();
            this.tbxInput5 = new System.Windows.Forms.TextBox();
            this.btnOutput01 = new System.Windows.Forms.Button();
            this.btnOutput02 = new System.Windows.Forms.Button();
            this.btnOutput03 = new System.Windows.Forms.Button();
            this.btnOutput04 = new System.Windows.Forms.Button();
            this.btnOutput05 = new System.Windows.Forms.Button();
            this.btnOutput06 = new System.Windows.Forms.Button();
            this.btnOutput07 = new System.Windows.Forms.Button();
            this.btnOutput08 = new System.Windows.Forms.Button();
            this.btnOutput09 = new System.Windows.Forms.Button();
            this.btnOutput10 = new System.Windows.Forms.Button();
            this.btnOutput11 = new System.Windows.Forms.Button();
            this.btnOutput12 = new System.Windows.Forms.Button();
            this.btnOutput13 = new System.Windows.Forms.Button();
            this.btnOutput14 = new System.Windows.Forms.Button();
            this.btnOutput15 = new System.Windows.Forms.Button();
            this.chkToggle = new System.Windows.Forms.CheckBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbxInput1
            // 
            this.tbxInput1.Location = new System.Drawing.Point(13, 13);
            this.tbxInput1.Name = "tbxInput1";
            this.tbxInput1.Size = new System.Drawing.Size(100, 21);
            this.tbxInput1.TabIndex = 0;
            // 
            // tbxInput2
            // 
            this.tbxInput2.Location = new System.Drawing.Point(119, 12);
            this.tbxInput2.Name = "tbxInput2";
            this.tbxInput2.Size = new System.Drawing.Size(100, 21);
            this.tbxInput2.TabIndex = 0;
            // 
            // tbxInput3
            // 
            this.tbxInput3.Location = new System.Drawing.Point(225, 13);
            this.tbxInput3.Name = "tbxInput3";
            this.tbxInput3.Size = new System.Drawing.Size(100, 21);
            this.tbxInput3.TabIndex = 0;
            // 
            // tbxInput4
            // 
            this.tbxInput4.Location = new System.Drawing.Point(332, 12);
            this.tbxInput4.Name = "tbxInput4";
            this.tbxInput4.Size = new System.Drawing.Size(100, 21);
            this.tbxInput4.TabIndex = 0;
            // 
            // tbxInput5
            // 
            this.tbxInput5.Location = new System.Drawing.Point(438, 12);
            this.tbxInput5.Name = "tbxInput5";
            this.tbxInput5.Size = new System.Drawing.Size(100, 21);
            this.tbxInput5.TabIndex = 0;
            // 
            // btnOutput01
            // 
            this.btnOutput01.Location = new System.Drawing.Point(14, 49);
            this.btnOutput01.Name = "btnOutput01";
            this.btnOutput01.Size = new System.Drawing.Size(100, 23);
            this.btnOutput01.TabIndex = 1;
            this.btnOutput01.UseVisualStyleBackColor = true;
            this.btnOutput01.Click += new System.EventHandler(this.btnOutput01_Click);
            // 
            // btnOutput02
            // 
            this.btnOutput02.Location = new System.Drawing.Point(119, 49);
            this.btnOutput02.Name = "btnOutput02";
            this.btnOutput02.Size = new System.Drawing.Size(100, 23);
            this.btnOutput02.TabIndex = 1;
            this.btnOutput02.UseVisualStyleBackColor = true;
            this.btnOutput02.Click += new System.EventHandler(this.btnOutput02_Click);
            // 
            // btnOutput03
            // 
            this.btnOutput03.Location = new System.Drawing.Point(226, 49);
            this.btnOutput03.Name = "btnOutput03";
            this.btnOutput03.Size = new System.Drawing.Size(100, 23);
            this.btnOutput03.TabIndex = 1;
            this.btnOutput03.UseVisualStyleBackColor = true;
            this.btnOutput03.Click += new System.EventHandler(this.btnOutput03_Click);
            // 
            // btnOutput04
            // 
            this.btnOutput04.Location = new System.Drawing.Point(332, 49);
            this.btnOutput04.Name = "btnOutput04";
            this.btnOutput04.Size = new System.Drawing.Size(100, 23);
            this.btnOutput04.TabIndex = 1;
            this.btnOutput04.UseVisualStyleBackColor = true;
            this.btnOutput04.Click += new System.EventHandler(this.btnOutput04_Click);
            // 
            // btnOutput05
            // 
            this.btnOutput05.Location = new System.Drawing.Point(438, 49);
            this.btnOutput05.Name = "btnOutput05";
            this.btnOutput05.Size = new System.Drawing.Size(100, 23);
            this.btnOutput05.TabIndex = 1;
            this.btnOutput05.UseVisualStyleBackColor = true;
            this.btnOutput05.Click += new System.EventHandler(this.btnOutput05_Click);
            // 
            // btnOutput06
            // 
            this.btnOutput06.Location = new System.Drawing.Point(13, 78);
            this.btnOutput06.Name = "btnOutput06";
            this.btnOutput06.Size = new System.Drawing.Size(100, 23);
            this.btnOutput06.TabIndex = 1;
            this.btnOutput06.UseVisualStyleBackColor = true;
            this.btnOutput06.Click += new System.EventHandler(this.btnOutput06_Click);
            // 
            // btnOutput07
            // 
            this.btnOutput07.Location = new System.Drawing.Point(119, 78);
            this.btnOutput07.Name = "btnOutput07";
            this.btnOutput07.Size = new System.Drawing.Size(100, 23);
            this.btnOutput07.TabIndex = 1;
            this.btnOutput07.UseVisualStyleBackColor = true;
            // 
            // btnOutput08
            // 
            this.btnOutput08.Location = new System.Drawing.Point(226, 78);
            this.btnOutput08.Name = "btnOutput08";
            this.btnOutput08.Size = new System.Drawing.Size(100, 23);
            this.btnOutput08.TabIndex = 1;
            this.btnOutput08.UseVisualStyleBackColor = true;
            // 
            // btnOutput09
            // 
            this.btnOutput09.Location = new System.Drawing.Point(332, 78);
            this.btnOutput09.Name = "btnOutput09";
            this.btnOutput09.Size = new System.Drawing.Size(100, 23);
            this.btnOutput09.TabIndex = 1;
            this.btnOutput09.UseVisualStyleBackColor = true;
            // 
            // btnOutput10
            // 
            this.btnOutput10.Location = new System.Drawing.Point(438, 78);
            this.btnOutput10.Name = "btnOutput10";
            this.btnOutput10.Size = new System.Drawing.Size(100, 23);
            this.btnOutput10.TabIndex = 1;
            this.btnOutput10.UseVisualStyleBackColor = true;
            // 
            // btnOutput11
            // 
            this.btnOutput11.Location = new System.Drawing.Point(13, 107);
            this.btnOutput11.Name = "btnOutput11";
            this.btnOutput11.Size = new System.Drawing.Size(100, 23);
            this.btnOutput11.TabIndex = 1;
            this.btnOutput11.UseVisualStyleBackColor = true;
            // 
            // btnOutput12
            // 
            this.btnOutput12.Location = new System.Drawing.Point(119, 107);
            this.btnOutput12.Name = "btnOutput12";
            this.btnOutput12.Size = new System.Drawing.Size(100, 23);
            this.btnOutput12.TabIndex = 1;
            this.btnOutput12.UseVisualStyleBackColor = true;
            // 
            // btnOutput13
            // 
            this.btnOutput13.Location = new System.Drawing.Point(226, 107);
            this.btnOutput13.Name = "btnOutput13";
            this.btnOutput13.Size = new System.Drawing.Size(100, 23);
            this.btnOutput13.TabIndex = 1;
            this.btnOutput13.UseVisualStyleBackColor = true;
            // 
            // btnOutput14
            // 
            this.btnOutput14.Location = new System.Drawing.Point(332, 107);
            this.btnOutput14.Name = "btnOutput14";
            this.btnOutput14.Size = new System.Drawing.Size(100, 23);
            this.btnOutput14.TabIndex = 1;
            this.btnOutput14.UseVisualStyleBackColor = true;
            // 
            // btnOutput15
            // 
            this.btnOutput15.Location = new System.Drawing.Point(438, 107);
            this.btnOutput15.Name = "btnOutput15";
            this.btnOutput15.Size = new System.Drawing.Size(100, 23);
            this.btnOutput15.TabIndex = 1;
            this.btnOutput15.UseVisualStyleBackColor = true;
            // 
            // chkToggle
            // 
            this.chkToggle.AutoSize = true;
            this.chkToggle.Location = new System.Drawing.Point(545, 12);
            this.chkToggle.Name = "chkToggle";
            this.chkToggle.Size = new System.Drawing.Size(15, 14);
            this.chkToggle.TabIndex = 2;
            this.chkToggle.UseVisualStyleBackColor = true;
            // 
            // lblResult
            // 
            this.lblResult.BackColor = System.Drawing.Color.White;
            this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblResult.Location = new System.Drawing.Point(14, 156);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(525, 268);
            this.lblResult.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.chkToggle);
            this.Controls.Add(this.btnOutput15);
            this.Controls.Add(this.btnOutput10);
            this.Controls.Add(this.btnOutput05);
            this.Controls.Add(this.btnOutput14);
            this.Controls.Add(this.btnOutput09);
            this.Controls.Add(this.btnOutput04);
            this.Controls.Add(this.btnOutput13);
            this.Controls.Add(this.btnOutput08);
            this.Controls.Add(this.btnOutput03);
            this.Controls.Add(this.btnOutput12);
            this.Controls.Add(this.btnOutput07);
            this.Controls.Add(this.btnOutput02);
            this.Controls.Add(this.btnOutput11);
            this.Controls.Add(this.btnOutput06);
            this.Controls.Add(this.btnOutput01);
            this.Controls.Add(this.tbxInput5);
            this.Controls.Add(this.tbxInput4);
            this.Controls.Add(this.tbxInput3);
            this.Controls.Add(this.tbxInput2);
            this.Controls.Add(this.tbxInput1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxInput1;
        private System.Windows.Forms.TextBox tbxInput2;
        private System.Windows.Forms.TextBox tbxInput3;
        private System.Windows.Forms.TextBox tbxInput4;
        private System.Windows.Forms.TextBox tbxInput5;
        private System.Windows.Forms.Button btnOutput01;
        private System.Windows.Forms.Button btnOutput02;
        private System.Windows.Forms.Button btnOutput03;
        private System.Windows.Forms.Button btnOutput04;
        private System.Windows.Forms.Button btnOutput05;
        private System.Windows.Forms.Button btnOutput06;
        private System.Windows.Forms.Button btnOutput07;
        private System.Windows.Forms.Button btnOutput08;
        private System.Windows.Forms.Button btnOutput09;
        private System.Windows.Forms.Button btnOutput10;
        private System.Windows.Forms.Button btnOutput11;
        private System.Windows.Forms.Button btnOutput12;
        private System.Windows.Forms.Button btnOutput13;
        private System.Windows.Forms.Button btnOutput14;
        private System.Windows.Forms.Button btnOutput15;
        private System.Windows.Forms.CheckBox chkToggle;
        private System.Windows.Forms.Label lblResult;
    }
}

